Reemax's [LPC] Items and Game Effects https://opengameart.org/content/lpc-items-and-game-effects
wulax's [LPC]Medieval Fantasy Character Sprites: https://opengameart.org/content/lpc-medieval-fantasy-character-sprites
DarkwallLKE's Kite Shield: http://darkwalllke.com and https://opengameart.org/content/lpc-kite-shield

CC-BY-SA 3.0 CC GPL3.0 CC GPL 2.0

Modifications by Michael Whitlock, please credit me and the original artist.