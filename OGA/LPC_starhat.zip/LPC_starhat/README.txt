LPC Wizard Star Hat by Michael Whitlock (bear)
Based on Merlin's Hat (https://opengameart.org/content/merlins-hat) by Tracy under CC-BY 3.0